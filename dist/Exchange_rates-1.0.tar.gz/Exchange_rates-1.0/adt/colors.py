# Includes available colors


class AvailableColors:
    BLACK = 'rgb(0, 0, 0)'
    RED = 'rgb(165,0,38)'
    PINK = '#FFBAD2'
    ORANGE = '#FF9900'
    PURPLE = '#8800FF'
